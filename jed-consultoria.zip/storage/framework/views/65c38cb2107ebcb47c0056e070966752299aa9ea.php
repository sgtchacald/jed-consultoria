

<?php $__env->startSection('conteudo'); ?>
    
    <section class="section section-intro context-dark">
        <div class="intro-bg"
            style="background: url(<?php echo e(asset('site/images/intro-pagina-contato.jpg')); ?>) no-repeat;background-size:cover;background-position: top center;">
        </div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 text-center">
                    <h1 class="font-weight-bold wow fadeInLeft"><?php echo e(Parametro::get('PG_CONTATO_TITULO')); ?></h1>
                    <p class="intro-description wow fadeInRight"><?php echo e(Parametro::get('PG_CONTATO_TITULO_TEXTO')); ?>.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Formulário de envio de email -->
    <section class="section section-md">
        <div class="container">
            <!--RD Mailform-->
            <div class="row justify-content-center">
                <div class="col-12 text-center col-md-10 col-lg-8">
                    <div class="section-name wow fadeInRight" data-wow-delay=".2s">
                        <?php echo e(Config::get('label.contato_subtitulo')); ?></div>
                    <h3 class="wow fadeInLeft" data-wow-delay=".3s"><?php echo e(Config::get('label.contato_titulo')); ?></h3>
                    <p>Nós temos a melhor assessoria</p>
                </div>

                <div class="col-xl-6 col-md-8 col-12">
                    <form name="formContato" id="formContato" method="post" action="<?php echo e(route('site.contato.enviar')); ?>">
                        <div class="card-body">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-12">
                                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(Session::has('alert-' . $msg)): ?>
                                            <div class="alert alert-<?php echo e($msg); ?> alert-dismissible desaparecer"
                                                role="alert">
                                                <button type="button" class="close" data-dismiss="alert"
                                                    aria-hidden="true">×</button>
                                                <?php echo e(Session::get('alert-' . $msg)); ?>

                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="form-group required">
                                        <label class="negrito"><?php echo e(Config::get('label.nome')); ?>:</label>

                                        <input type="text" name="nome" id="nome"
                                            class="form-control <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="<?php echo e(Config::get('label.nome_placeholder')); ?>" maxlength="100"
                                            value="<?php echo e(old('nome')); ?>">

                                        <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group required">
                                        <label class="negrito"><?php echo e(Config::get('label.email')); ?>:</label>

                                        <input type="text" name="email" id="email"
                                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="<?php echo e(Config::get('label.email_placeholder')); ?>" maxlength="100"
                                            value="<?php echo e(old('email')); ?>">

                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group required">
                                        <label class="negrito"><?php echo e(Config::get('label.telefone')); ?>:</label>

                                        <input type="text" id="telefone" name="telefone"
                                            class="form-control <?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> phone"
                                            placeholder="<?php echo e(Config::get('label.telefone_placeholder')); ?>"
                                            maxlength="11"
                                            value="<?php echo e(old('telefone')); ?>">

                                        <?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group required">
                                        <label class="negrito"><?php echo e(Config::get('label.contato_assunto')); ?>:</label>
                                        <select name="assunto" id="assunto"
                                            class="form-control <?php $__errorArgs = ['assunto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> readyOnly" readonly>
                                            <option value="">Selecione</option>
                                            <?php $__currentLoopData = \App\Http\Controllers\Admin\ServicosController::getServicosHierarquicamente(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($servico->idpai == ''): ?>
                                                    <option <?php if(old('assunto') == $servico->id): ?> <?php echo e('selected="selected"'); ?> <?php endif; ?> value="<?php echo e($servico->id); ?>">
                                                        <?php echo e($servico->nome); ?>

                                                    </option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                        <input type="hidden" id="strAssunto" name="strAssunto" value="">

                                        <?php $__errorArgs = ['assunto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group required">
                                        <label
                                            class="negrito"><?php echo e(Config::get('label.contato_mensagem')); ?>:</label>

                                        <textarea name="mensagem" id="textarea"
                                            class="form-control <?php $__errorArgs = ['mensagem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> tamanhoMaxlenght"
                                            placeholder="<?php echo e(Config::get('label.contato_mensagem_placeholder')); ?>"
                                            rows="5" maxlength="1024"
                                            style="text-align: justify;"><?php echo e(old('mensagem')); ?></textarea>

                                        <span id="chars">1024</span> caracteres restantes.

                                        <?php $__errorArgs = ['mensagem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>


                                </div>
                            </div>

                            <div class="">
                                <button type="submit" class="btn btn-primary">Enviar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!--Google Maps-->
    <section class="section">
        <div id="mapa" style="width: 100%; height: 300px;"></div>
    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type='text/javascript' src='//igorescobar.github.io/jQuery-Mask-Plugin/js/jquery.mask.min.js'></script>

    <script type="text/javascript">
        var select = document.querySelector('select');


        select.addEventListener('change', function() {
            var option = this.selectedOptions[0];
            var texto = option.textContent;

            document.getElementById('strAssunto').value = texto.trim();
        });

        var locations = [
            ['JED Consultoria', -22.75710143519233, -43.44852097951658, 1]
        ];

        var map = new google.maps.Map(document.getElementById('mapa'), {
            zoom: 18,
            center: new google.maps.LatLng(-22.75725845215196, -43.448526716900744),
            mapTypeId: google.maps.MapTypeId.ROADMAP
        });

        var infowindow = new google.maps.InfoWindow();

        var marker, i;

        for (i = 0; i < locations.length; i++) {
            marker = new google.maps.Marker({
                position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                map: map
            });

            google.maps.event.addListener(marker, 'click', (function(marker, i) {
                return function() {
                    infowindow.setContent(locations[i][0]);
                    infowindow.open(map, marker);
                }
            })(marker, i));
        }


        function somenteNumeros(e) {
            var charCode = e.charCode ? e.charCode : e.keyCode;
            // charCode 8 = backspace
            // charCode 9 = tab
            if (charCode != 8 && charCode != 9) {
                // charCode 48 equivale a 0
                // charCode 57 equivale a 9
                if (charCode < 48 || charCode > 57) {
                    return false;
                }
            }
        }

        var behavior = function (val) {
            return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
        },
        options = {
            onKeyPress: function (val, e, field, options) {
                field.mask(behavior.apply({}, arguments), options);
            }
        };

        $('.phone').mask(behavior, options);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jed-consultoria\resources\views/site/contato.blade.php ENDPATH**/ ?>