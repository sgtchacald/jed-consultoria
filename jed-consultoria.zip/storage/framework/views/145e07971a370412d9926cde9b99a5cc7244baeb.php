

<?php $__env->startSection('conteudo'); ?>
    <!--Introdução -->
    <section class="section section-intro context-dark">
        <div class="intro-bg"
            style="background: url(<?php echo e(asset('site/images/intro-bg-1.jpg')); ?>) no-repeat;background-size:cover;background-position: top center;">
        </div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 text-center">
                    <h1 class="font-weight-bold wow fadeInLeft"><?php echo e(Parametro::get('PG_SOBRE_TITULO')); ?></h1>
                    <p class="intro-description wow fadeInRight"><?php echo e(Parametro::get('PG_SOBRE_DESCRICAO')); ?></p>
                </div>
            </div>
        </div>

        <div class="col-12 text-center offset-top-75" data-wow-delay=".2s">
            <a class="button-way-point d-inline-block text-center d-inline-flex flex-column justify-content-center" href="#"
                data-custom-scroll-to="sobre">
                <span class="fa-chevron-down"></span>
            </a>
        </div>
    </section>

    <!-- Sobre -->
    <section id="sobre" class="section section-md">
        <div class="container">
            <div class="row row-40 justify-content-center">
                <div class="col-lg-6 col-12">
                    <div class="offset-top-45 offset-lg-right-45">
                        <div class="section-name wow fadeInRight" data-wow-delay=".2s">
                            <?php echo e(Parametro::get('PG_SOBRE_TITULO')); ?></div>
                        <h3 class="wow fadeInLeft text-capitalize" data-wow-delay=".3s">
                            <?php echo e(Parametro::get('PI_SOBRE_SUBTITULO')); ?></h3>
                        <p class="wow fadeInUp" data-wow-delay=".4s"><?php echo e(Parametro::get('PI_SOBRE_TEXTO')); ?></p>
                        <p class="wow fadeInUp" data-wow-delay=".4s"><?php echo e(Parametro::get('PI_SOBRE_TEXTO_NEGRITO')); ?></p>
                        <br>
                        <h5 class="wow fadeInLeft" data-wow-delay=".3s">Abaixo estão alguns de nossos serviços:</h5>
                    </div>

                    <div class="offset-top-20">

                        <!--Linear progress bar-->
                        <?php $__currentLoopData = \App\Http\Controllers\Admin\ServicosController::getServicosPaiAleatorios(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($servico->idpai == ''): ?>
                                <article class="progress-linear" style="margin-top: 10px !important;">
                                    <div class="progress-header progress-header-simple">
                                        <p class="" data-wow-delay=".4s"><?php echo e($servico->nome); ?></p>
                                    </div>

                                    <div class="progress" style="height: 5px; margin-top: 15px;">
                                        <div class="progress-bar progress-bar-animated button-primary" role="progressbar"
                                            aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">
                                        </div>
                                    </div>
                                </article>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <a class="button-width-190 button-primary button-circle button-lg button offset-top-30" href="<?php echo e(route('site.servicos')); ?>" >Veja Todos</a>
                    </div>
                </div>

                <div class="col-lg-6 col-sm-10 col-12">
                    <div class="block-decorate-img wow fadeInLeft" data-wow-delay=".2s">
                        <img src="<?php echo e(asset('site/images/about-1-570x703.jpg')); ?>" alt="" width="570" height="351" />
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Colaboradores -->
    <section class="section section-md">
        <div class="container">
            <div class="row row-50 justify-content-center">
                <div class="col-md col-12 text-center">
                    <div class="section-name wow fadeInRight" data-wow-delay=".2s">
                        <?php echo e(Parametro::get('PG_SOBRE_COLABORADOR_TITULO')); ?></div>

                    <h3 class="wow fadeInLeft text-capitalize" data-wow-delay=".3s">
                        <?php echo e(Parametro::get('PG_SOBRE_COLABORADOR_SUBTITULO')); ?>

                    </h3>
                </div>
            </div>

            <div class="row row-50 justify-content-center">
                <?php $__currentLoopData = (object) \App\Http\Controllers\Admin\UsuariosController::getUsuarios(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(($usuario->urlimagem != null || $usuario->urlimagem != '') && $usuario->indcolaborador == 'S'): ?>
                        <div class="col-xl-4 col-sm-6 col-10 wow fadeInLeft" data-wow-delay=".3s">
                            <div class="team-classic-wrap">
                                <div class="team-classic-img">
                                    <img src="<?php echo e(route('getimagem', $usuario->urlimagem)); ?>"
                                        alt="<?php echo e($usuario->urlimagem); ?>" width="370" height="198" />
                                </div>
                                <div class="block-320 text-center">
                                    <h4 class="font-weight-bold">
                                        <?php echo e(\App\Http\Controllers\Utils\UtilsController::gePrimeiroNomeUltimoSobrenome($usuario->name)); ?>

                                    </h4>

                                    <span class="d-block"><?php echo e($usuario->cargo); ?></span>

                                    <p><?php echo e($usuario->descricaocargo); ?></p>

                                    <hr class="offset-top-40" />

                                    <ul class="justify-content-center social-links offset-top-30">
                                        <?php if($usuario->urllinkedin != ''): ?>
                                            <li><a class="fa fa-linkedin" href="<?php echo e($usuario->urllinkedin); ?>" target="_blank"></a></li>
                                        <?php endif; ?>

                                        <?php if($usuario->urltwitter != ''): ?>
                                            <li><a class="fa fa fa-twitter" href="<?php echo e($usuario->urltwitter); ?>" target="_blank"></a></li>
                                        <?php endif; ?>

                                        <?php if($usuario->urlfacebook != ''): ?>
                                            <li><a class="fa fa-facebook" href="<?php echo e($usuario->urlfacebook); ?>" target="_blank"></a></li>
                                        <?php endif; ?>

                                        <?php if($usuario->urlinstagram != ''): ?>
                                            <li><a class="fa fa-instagram" href="<?php echo e($usuario->urlinstagram); ?>" target="_blank"></a></li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!--Parceiros -->
    <section class="section section-md">
        <div class="container justify-content-center">
            <div class="row row-50 justify-content-center">
                <div class="col-md col-12 text-center">
                    <div class="section-name wow fadeInRight" data-wow-delay=".2s">
                        Uma parceria é fundamental para qualquer negócio.
                    </div>

                    <h3 class="wow fadeInLeft text-capitalize" data-wow-delay=".3s">
                        Nossos Parceiros
                    </h3>
                </div>
            </div>

            <div class="row">
                <!-- Owl Carousel-->
                <div class="owl-carousel text-center owl-brand"
                    data-items="1"
                    data-sm-items="2"
                    data-md-items="3"
                    data-lg-items="3"
                    data-xl-items="5"
                    data-xxl-items="5"
                    data-dots="true"
                    data-nav="false"
                    data-stage-padding="15"
                    data-loop="false"
                    data-margin="30"
                    data-mouse-drag="true"
                    data-autoplay="true">


                    <?php $__currentLoopData = (object) \App\Http\Controllers\Admin\ParceirosController::getParceiros(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parceiro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(($parceiro->urlimagem != null || $parceiro->urlimagem != '') && $parceiro->indexibirparceiro == 'S'): ?>
                            <div class="item" style="border-style:solid 1px; color: #923898 !important"><img src="<?php echo e(route('getimagem', $parceiro->urlimagem)); ?>" alt="" width="200" height="24" /></div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

    <div id="modais" class="ocultar"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jed-consultoria\resources\views/site/sobre.blade.php ENDPATH**/ ?>