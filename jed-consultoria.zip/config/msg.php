<?php
  return  array(
    //Mensagens Genéricas
    'cadastro_sucesso' => 'Registro incluido com sucesso.',
    'cadastro_erro' => 'Falha ao incluir registro.',
    'edicao_sucesso' => 'Registro Alterado com sucesso.',
    'edicao_erro' => 'Falha ao incluir registro.',
    'exclusao_sucesso' => 'Registro Excluído com sucesso.',
    'exclusao_erro' => 'Falha ao Excluir registro.',
    'exclusao_erro_arquivo' => 'Falha ao excluir arquivo anexo, verifique com o administrador.',
    'existe_registro' => 'Já existe um registro com essas características, não é necessário continuar esta operação.',
    //Mensagen(s) Serviços
    'exclusao_servico_vinculado' => 'Existe um serviço vinculado a este registro, esta operação não pôde ser concluída.',
    //Mensagen(s) Formulário de Contato
    'contato_sucesso' => 'Seu contato foi enviado com sucesso!',
    'contato_erro' => 'Erro ao enviar o forulário de contato.',
    'contato_msg_lida_sucesso' => 'A mensagem foi lida com sucesso.',
    'contato_msg_lida_erro' => 'Erro ao ler mensagem.',


  );
