<?php
//Caminhos parametrizados do sistema
  return  array(
    'uploads' => 'public/uploads',
    'uploads_recuperar' => 'app/public/uploads',
  );
