<!-- Modal -->
<div class="modal fade excluir" tabindex="-1" role="dialog" aria-labelledby="titulo-da-modal" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color:#923898 !important;">
                <h5 class="modal-title" id="titulo-da-modal" style="color:#FFFFFF !important;">
                    <span class="titulo-modal"></span>
                </h5>

                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="container-fluid">
                    <div class="row conteudo-modal">
                    </div>
                </div>
                <span class="conteudo-modal"></span>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>
