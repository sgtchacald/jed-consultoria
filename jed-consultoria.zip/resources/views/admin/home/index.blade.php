@extends('adminlte::page')

@section('title', 'JED - Administração do Site')

@section('content_header')
    <h1>Dashboard</h1>
@stop

@section('content')
    <p>Nesta seção é possivel criar/alterar novas configurações para o site.</p>
@stop
